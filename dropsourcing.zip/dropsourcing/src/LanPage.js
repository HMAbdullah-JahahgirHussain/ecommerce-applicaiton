import { Component } from "react";
import { Link  } from 'react-router-dom';
import './assets/css/style2827.css';
import './assets/css/et-core-unified-23055-16679997200396.min.css';
import MainHeader from "./components/MainHeader";

class LanPage extends Component{
    render() {
        return (
            <>
            <MainHeader />
            <div id="page-container">  
               <div id="et-main-area">
                  <div id="main-content">
                     <article id="post-23055" className="post-23055 page type-page status-publish hentry">
                        <div className="entry-content">
                           <div id="et-boc" className="et-boc">
                              <div className="et-l et-l--post">
                                 <div className="et_builder_inner_content et_pb_gutters3">
                                    <div className="et_pb_section et_pb_section_0 et_section_regular">
                                       <div className="et_pb_row et_pb_row_0">
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_0  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_video et_pb_video_0">
                                                <div className="et_pb_video_box">
                                                   <video controls>
                                                      <source type="video/mp4" src="./assets/imgs/main_video.mp4" />
                                                   </video>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_1  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_text et_pb_text_0  et_pb_text_align_center et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h1 className="et_pb_module_header">Dropsourcing</h1>
                                                   <p><span>Pakistan&#8217;s First &amp; Biggest Dropshipping Platform for Online Sellers</span>.</p>
                                                </div>
                                             </div>
                                             <div className="et_pb_button_module_wrapper et_pb_button_0_wrapper et_pb_button_alignment_center et_pb_module ">
                                                <Link to="/register" className="et_pb_button et_pb_button_0 et_pb_bg_layout_light">Register/Apply Now</Link>
                                             </div>
                                             <div className="et_pb_button_module_wrapper et_pb_button_1_wrapper et_pb_button_alignment_center et_pb_module ">
                                                <Link to="/login" className="et_pb_button et_pb_button_1 et_pb_bg_layout_light">Login</Link>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="et_pb_section et_pb_section_1 et_section_regular">
                                       <div className="et_pb_row et_pb_row_1">
                                          <div className="et_pb_column et_pb_column_4_4 et_pb_column_2  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_text et_pb_text_1  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h2 style={{textAlign: 'center'}}><strong>Here is How Dropshipping Works</strong></h2>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="et_pb_section et_pb_section_2 et_section_regular">
                                       <div className="et_pb_row et_pb_row_2">
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_3  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_with_border et_pb_module et_pb_image et_pb_image_0">
                                                <span className="et_pb_image_wrap "><img src="./assets/uploads/2021/02/5.png" alt="" title="5" sizes="(min-width: 0px) and (max-width: 480px) 480px, (min-width: 481px) and (max-width: 980px) 980px, (min-width: 981px) 1080px, 100vw" /></span>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_4  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_image et_pb_image_1">
                                                <span className="et_pb_image_wrap "><img src="./assets/uploads/2021/02/6-1.png" alt="" title="6" sizes="(min-width: 0px) and (max-width: 480px) 480px, (min-width: 481px) and (max-width: 980px) 980px, (min-width: 981px) 1080px, 100vw" /></span>
                                             </div>
                                          </div>
                                       </div>
                                       <div className="et_pb_row et_pb_row_3">
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_5  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_image et_pb_image_2">
                                                <span className="et_pb_image_wrap "><img src="./assets/uploads/2021/02/7.png" alt="" title="7" sizes="(min-width: 0px) and (max-width: 480px) 480px, (min-width: 481px) and (max-width: 980px) 980px, (min-width: 981px) 1080px, 100vw" /></span>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_6  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_image et_pb_image_3">
                                                <span className="et_pb_image_wrap "><img src="./assets/uploads/2021/02/8.png" alt="" title="8" sizes="(min-width: 0px) and (max-width: 480px) 480px, (min-width: 481px) and (max-width: 980px) 980px, (min-width: 981px) 1080px, 100vw" /></span>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="et_pb_section et_pb_section_3 et_section_regular">
                                       <div className="et_pb_row et_pb_row_4">
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_7  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_divider et_pb_divider_0 et_pb_divider_position_ et_pb_space">
                                                <div className="et_pb_divider_internal"></div>
                                             </div>
                                             <div className="et_pb_module et_pb_text et_pb_text_2  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h2>We Help you build your online business with little to no investment at all</h2>
                                                </div>
                                             </div>
                                             <div className="et_pb_module et_pb_image et_pb_image_4">
                                                <span className="et_pb_image_wrap "><img src="./assets/uploads/2021/02/interpreter-30.png" alt="" title="interpreter-30" sizes="(min-width: 0px) and (max-width: 480px) 480px, (min-width: 481px) and (max-width: 980px) 980px, (min-width: 981px) 1280px, 100vw" /></span>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_8  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_0  et_pb_text_align_left  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/interpreter-icon-26.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>We've got the resources</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p><span>Located at Saddar, central business hub of Pakistan, with vast network of manufacturers, importers and all the logistics heads within reach of just few steps. We make it possible to build your empire hassle free and smooth.</span></p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_1  et_pb_text_align_left  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/interpreter-icon-18.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Evergrowing Industry</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p><span>Now get your hands dirty in worlds fastest growing industry without even leaving the comfort of your home.</span></p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_2  et_pb_text_align_left  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/interpreter-icon-16.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Experienced Team</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p><span>Experienced operational team in every step and department. Making your business perform smooth and easy</span></p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                              
                                    <div className="et_pb_section et_pb_section_4 et_section_regular">
                                       <div className="et_pb_row et_pb_row_5 et_pb_gutters4">
                                          <div className="et_pb_column et_pb_column_4_4 et_pb_column_9  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_text et_pb_text_3  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h2>Reviews</h2>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                 {/* <?php echo do_shortcode('[elementor-template id="22"]');?> */}
                                    </div>
                                    <div className="et_pb_section et_pb_section_5 et_pb_with_background et_section_regular">
                                       <div className="et_pb_row et_pb_row_7">
                                          <div className="et_pb_column et_pb_column_4_4 et_pb_column_11  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_image et_pb_image_5">
                                                <span className="et_pb_image_wrap "><img src="./assets/uploads/2021/02/Path.png" alt="" title="Path" /></span>
                                             </div>
                                             <div className="et_pb_module et_pb_image et_pb_image_6">
                                                <span className="et_pb_image_wrap "><img src="./assets/uploads/2021/02/Path-1.png" alt="" title="Path" /></span>
                                             </div>
                                             <div className="et_pb_module et_pb_divider et_pb_divider_1 et_pb_divider_position_ et_pb_space">
                                                <div className="et_pb_divider_internal"></div>
                                             </div>
                                             <div className="et_pb_module et_pb_text et_pb_text_4  et_pb_text_align_center et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h2>Thousands of Winning Products &amp; Growing Everyday</h2>
                                                   <p><span>From casual slippers, to extremely uninque and branded items. We provide them all. Also major focus on providing our dropshippers with the most in demand and trending products</span></p>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div className="et_pb_row et_pb_row_8 et_pb_gutters2">
                                          <div className="et_pb_column et_pb_column_1_4 et_pb_column_12  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_3  et_pb_text_align_center  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/Decoration-Icon-e1613995872855.jpg" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Decoration Items</span></h4>
                                                   </div>
                                                </div>
                                             </div>
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_4  et_pb_text_align_center  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/womens-fashion-accessroes-e1613998498258.jpg" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Womens Accessories</span></h4>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_4 et_pb_column_13  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_5  et_pb_text_align_center  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/gift-item-e1613996987178.jpg" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Gift Items</span></h4>
                                                   </div>
                                                </div>
                                             </div>
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_6  et_pb_text_align_center  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/handbags-icon-e1613997640885.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Handbags</span></h4>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_4 et_pb_column_14  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_7  et_pb_text_align_center  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/customized-items-icon-e1613997465471.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Customized Items</span></h4>
                                                   </div>
                                                </div>
                                             </div>
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_8  et_pb_text_align_center  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/mens-accessores.jpg" alt="" sizes="(max-width: 160px) 100vw, 160px" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Men's Accessories</span></h4>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_4 et_pb_column_15  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_9  et_pb_text_align_center  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/kitchen-accessories-icon-e1613997207964.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Kitchen Household Accessories</span></h4>
                                                   </div>
                                                </div>
                                             </div>
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_10  et_pb_text_align_center  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/branded-e1613999226689.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Branded Items</span></h4>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="et_pb_section et_pb_section_6 et_pb_with_background et_section_regular">
                                       <div className="et_pb_row et_pb_row_9">
                                          <div className="et_pb_column et_pb_column_4_4 et_pb_column_16  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_divider et_pb_divider_2 et_pb_divider_position_ et_pb_space">
                                                <div className="et_pb_divider_internal"></div>
                                             </div>
                                             <div className="et_pb_module et_pb_divider et_pb_divider_3 et_pb_divider_position_ et_pb_space">
                                                <div className="et_pb_divider_internal"></div>
                                             </div>
                                             <div className="et_pb_module et_pb_text et_pb_text_5  et_pb_text_align_center et_pb_bg_layout_dark">
                                                <div className="et_pb_text_inner">
                                                   <h2>By Dropshipping, You save yourself from</h2>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div className="et_pb_row et_pb_row_10">
                                          <div className="et_pb_column et_pb_column_1_3 et_pb_column_17  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_11  et_pb_text_align_left  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/investment-icon-1-e1614000652282.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Huge Investments</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p>Dropshippers as compared to traditional ecommerce saves themselves up to 90% of infrastucture and other investments needed to run a successful ecommerce business</p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_3 et_pb_column_18  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_12  et_pb_text_align_left  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/stock-maintainence-icon-e1614000758398.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Stock Maintainence</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p>Keeping and managing stock is itself another level of management, which needs to be properly done in order to keep your head above the water in terms of product selection with good pricing, quality and sell-ability </p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_3 et_pb_column_19  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_13  et_pb_text_align_left  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/dispatch-pickup-hassle-e1614000837977.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Packaging & Disptach Hassles</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p>from arranging the packaging material to careful packaging and ensuring the safe and sound delivery of your products is one of the main operations of ecommerce business you save yourself from</p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div className="et_pb_row et_pb_row_11">
                                          <div className="et_pb_column et_pb_column_4_4 et_pb_column_20  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_text et_pb_text_6  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h2><strong>Also, Get the Benefits of</strong></h2>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div className="et_pb_row et_pb_row_12">
                                          <div className="et_pb_column et_pb_column_1_3 et_pb_column_21  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_14  et_pb_text_align_left  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/interpreter-icon-12.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Fast & Friendly Customer Support</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p>Available on your whatsapp, experienced team of customer support assistant helping your business overcome the dificulties you face</p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_3 et_pb_column_22  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_15  et_pb_text_align_left  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/interpreter-icon-19.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Delivering in Over 600 Cities</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p>In partnership with ecommerce experienced courier company, handling cash on deliveries, and high ratio of successful deliveries. we know how to get it done</p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_3 et_pb_column_23  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_16  et_pb_text_align_left  et_pb_blurb_position_top et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/interpreter-icon-14.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Complete Reporting</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p>Complete reportting of your orders with profit details and delivery status, you keep track of everything you need.</p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="et_pb_section et_pb_section_7 et_section_regular">
                                       <div className="et_pb_row et_pb_row_13">
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_24  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_divider et_pb_divider_4 et_pb_divider_position_ et_pb_space">
                                                <div className="et_pb_divider_internal"></div>
                                             </div>
                                             <div className="et_pb_module et_pb_text et_pb_text_7  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h2>About Us &amp; Why We are The Best For the Job</h2>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_25  et_pb_css_mix_blend_mode_passthrough et-last-child et_pb_column_empty"></div>
                                       </div>
                                       <div className="et_pb_row et_pb_row_14">
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_26  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_image et_pb_image_7">
                                                <span className="et_pb_image_wrap "><img src="./assets/uploads/2021/02/interpreter-84.png" alt="" title="interpreter-84" sizes="(min-width: 0px) and (max-width: 480px) 480px, (min-width: 481px) 800px, 100vw" /></span>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_27  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_17  et_pb_text_align_left  et_pb_blurb_position_left et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/interpreter-icon-18.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>The Best in the Business</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p><span>Importing products and being in the wholesale industry since a decade have made us realized the potential behind online industry and problems every startups face and the struggle it needs. We’ve seen it all and now we do our best to make your goal of running an ecommerce business as easy as possible.</span></p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div className="et_pb_module et_pb_blurb et_pb_blurb_18  et_pb_text_align_left  et_pb_blurb_position_left et_pb_bg_layout_light">
                                                <div className="et_pb_blurb_content">
                                                   <div className="et_pb_main_blurb_image"><span className="et_pb_image_wrap"><img src="./assets/uploads/2021/02/interpreter-icon-24.png" alt="" className="et-waypoint et_pb_animation_off" /></span></div>
                                                   <div className="et_pb_blurb_container">
                                                      <h4 className="et_pb_module_header"><span>Easy Online Booking</span></h4>
                                                      <div className="et_pb_blurb_description">
                                                         <p>Our online order booking system is the most easiest way you can book your orders online.</p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="et_pb_section et_pb_section_9 et_pb_with_background et_section_regular">
                                       <div className="et_pb_row et_pb_row_17">
                                          <div className="et_pb_column et_pb_column_4_4 et_pb_column_30  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_divider et_pb_divider_5 et_pb_divider_position_ et_pb_space">
                                                <div className="et_pb_divider_internal"></div>
                                             </div>
                                             <div className="et_pb_module et_pb_text et_pb_text_9  et_pb_text_align_center et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h2>Trusted by the 100&#8217;s of Ecommerce Experts</h2>
                                                </div>
                                             </div>
                                             <div className="et_pb_button_module_wrapper et_pb_button_2_wrapper et_pb_button_alignment_center et_pb_module ">
                                                <Link to="/register" className="et_pb_button et_pb_button_2 et_pb_bg_layout_light">Register Now</Link>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="et_pb_section et_pb_section_10 et_pb_with_background et_section_regular">
                                       <div className="et_pb_row et_pb_row_18">
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_31  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_divider et_pb_divider_6 et_pb_divider_position_ et_pb_space">
                                                <div className="et_pb_divider_internal"></div>
                                             </div>
                                             <div className="et_pb_module et_pb_text et_pb_text_10  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h2>We&#8217;re Ready to Help You Build Your Online Empire</h2>
                                                </div>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_32  et_pb_css_mix_blend_mode_passthrough et-last-child et_pb_column_empty"></div>
                                       </div>
                                       <div className="et_pb_row et_pb_row_19">
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_33  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_button_module_wrapper et_pb_button_3_wrapper  et_pb_module ">
                                                <Link to="/register" className="et_pb_button et_pb_button_3 et_pb_bg_layout_light">Apply Now for a Dropshipping Account</Link>
                                             </div>
                                          </div>
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_34  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_text et_pb_text_11  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <p>You Can Reach out to Us @</p>
                                                </div>
                                             </div>
                                             <div className="et_pb_module et_pb_text et_pb_text_13  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner"><a href="tel:03154254440">0315-4254440</a></div>
                                             </div>
                                             <div className="et_pb_module et_pb_text et_pb_text_14  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <p>Follow us on the Social Media</p>
                                                </div>
                                             </div>
                                             <ul className="et_pb_module et_pb_social_media_follow et_pb_social_media_follow_0 clearfix  et_pb_bg_layout_light">
                                                {/* <li className='et_pb_social_media_follow_network_0 et_pb_social_icon et_pb_social_network_link  et-social-facebook et_pb_social_media_follow_network_0'><a href='#' className='icon et_pb_with_border' title='Follow on Facebook' target="_blank"><span className='et_pb_social_media_follow_network_name' aria-hidden='true'>Follow</span></a></li>
                                                <li className='et_pb_social_media_follow_network_1 et_pb_social_icon et_pb_social_network_link  et-social-instagram et_pb_social_media_follow_network_1'><a href='#' className='icon et_pb_with_border' title='Follow on Instagram' target="_blank"><span className='et_pb_social_media_follow_network_name' aria-hidden='true'>Follow</span></a></li>
                                                <li className='et_pb_social_media_follow_network_2 et_pb_social_icon et_pb_social_network_link  et-social-youtube et_pb_social_media_follow_network_2'><a href='#' className='icon et_pb_with_border' title='Follow on Youtube' target="_blank"><span className='et_pb_social_media_follow_network_name' aria-hidden='true'>Follow</span></a></li> */}
                                             </ul>
                                          </div>
                                       </div>
                                       <div className="et_pb_row et_pb_row_20">
                                          <div className="et_pb_column et_pb_column_1_2 et_pb_column_35  et_pb_css_mix_blend_mode_passthrough et_pb_column_empty"></div>
                                          <div className="et_pb_column et_pb_column_1_4 et_pb_column_36  et_pb_css_mix_blend_mode_passthrough">
                                             <div className="et_pb_module et_pb_text et_pb_text_15  et_pb_text_align_left et_pb_bg_layout_light">
                                                <div className="et_pb_text_inner">
                                                   <h3>office</h3>
                                                   <p>Main Fazal pura, Kot Khawaja Saeed, LHR</p>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div className="et_pb_row et_pb_row_21">
                                          <div className="et_pb_column et_pb_column_4_4 et_pb_column_38  et_pb_css_mix_blend_mode_passthrough et-last-child">
                                             <div className="et_pb_module et_pb_image et_pb_image_8">
                                                <span className="et_pb_image_wrap "><img src="./assets/uploads/2021/02/interpreter-72.png" alt="" title="interpreter-72" sizes="(min-width: 0px) and (max-width: 480px) 480px, (min-width: 481px) and (max-width: 980px) 980px, (min-width: 981px) and (max-width: 1280px) 1280px, (min-width: 1281px) 2560px, 100vw" /></span>
                                             </div>
                                          </div>
                                       </div>
                                    </div>

                                 </div>
                              </div>
                           </div>
                        </div>
                     </article>
                  </div> 
               </div>
            </div>
         </>
        );
    }
}

export default LanPage;