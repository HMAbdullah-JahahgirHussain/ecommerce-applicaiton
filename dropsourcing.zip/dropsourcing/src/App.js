import LandingPage from './LanPage.js';
import './index.css';
import { BrowserRouter as Router, Route, Routes  } from 'react-router-dom';
import LoginP from "./components/Login_Page/login";
import RegisterP from "./components/Register/register";
import FooterSite from './components/footer';
import LostPass from './components/Login_Page/lostPass.js';
import UserDash from './components/Dashboard/Userdashboard.js';
import WishList from './components/Dashboard/wishlist.js';
import CartPage from './components/Dashboard/CartPage.js';
import CheckoutPage from './components/Dashboard/CheckoutPage.js';
import ProductDetailPage from './components/Dashboard/ProductDetailPage.js';



function App() {
  return (<>

    <Router>
          <Routes>
            <Route exact path="/" element={<LandingPage />}/>
            <Route exact path="/login" element={<LoginP/>}/>
            <Route exact path="/register" element={<RegisterP/>}/>
            <Route exact path="/lostPass" element={<LostPass/>}/>
            <Route exact path="/Udashboard" element={<UserDash/>}/>
            <Route exact path="/Wishlist" element={<WishList/>}/>
            <Route exact path="/cart" element={<CartPage/>}/>
            <Route exact path="/checkout" element={<CheckoutPage/>}/>
            <Route exact path="/ProductDetail" element={<ProductDetailPage/>}/>
            <Route path="*" element={<NotFound />}/>
          </Routes>
        </Router>
      <FooterSite />

    </>
  );
}

export default App;

const NotFound =()=>{
  return (
    <>
      <h1>404 Error Url not declaired!!!!</h1>
    </>
  );
}