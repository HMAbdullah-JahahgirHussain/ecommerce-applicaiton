import { Link  } from 'react-router-dom';
import SiteImg from '../imgs/site_logo.png';


const MainHeader = () => {
    return (
        <nav className="Main-nav-DS">
          <ul>
            <li className="active site_logo_ds">
              <Link to="/"><img src={SiteImg} alt="Site-Logo" /></Link>
            </li>
            <li className='login_mbr_btn'>
              <Link to="/login">Login Member</Link>
            </li>
          </ul>
        </nav>
    );
}
export default MainHeader;