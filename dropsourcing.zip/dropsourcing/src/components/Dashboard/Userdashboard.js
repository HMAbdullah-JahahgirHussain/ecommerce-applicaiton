import NavBarAafterLogin from "../NavB_AL";
import SideBar from "../SidebarN";
// import CartPage from "./CartPage";
import ShopPage from "./ShopP";

const UserDash = () => {
    return (
        <>
            <NavBarAafterLogin />
            <div className="dashboard_u">
                <SideBar/>
                <ShopPage />
            </div>    
        </>
    );
}

export default UserDash;