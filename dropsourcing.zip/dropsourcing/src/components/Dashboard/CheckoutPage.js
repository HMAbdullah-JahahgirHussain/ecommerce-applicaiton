import NavBarAafterLogin from '../NavB_AL';
import SideBar from '../SidebarN';
import './CheckoutPageM.css';


const CheckoutPage = () =>{
    return (<>
        <NavBarAafterLogin/>
        <div className="dashboard_u">
            <SideBar/>  
            <div className="S_CartPage_Main">
                <div className='CommanPageHeaderTitle'>
                    <h3>Checkout</h3>
                </div>
                <div className='S_Checkout_total_Main'>
                <div className='SCheckoutTM_BankDetails'>
                    <div className="checkout_Bdetails_T">
                        <p>Billing & Shipping</p>
                    </div>
                    <div className="ScheckBDs">
                        <label className="lg_label">Customer's Full Name <span className="strk_must">*</span></label>
                        <input type="text" placeholder="Enter Customer Name"/>
                        <label className="lg_label">Customer's Full Address <span className="strk_must">*</span></label>
                        <input type="text" placeholder="Enter Address"/>
                        <label className="lg_label">Courier Service <span className="strk_must">*</span></label>
                        <input type="text" placeholder="Type of courier service"/>
                        <label className="lg_label">Customer's Phone Number <span className="strk_must">*</span></label>
                        <input type="text" placeholder="Enter Customer Number"/>
                        <label className="lg_label">Sell Price <span className="strk_must">*</span></label>
                        <input type="text" placeholder=""/>
                        <label className="lg_label">Your Business Name <span className="strk_must">*</span></label>
                        <input type="text" placeholder="xyz"/>
                    </div>
                </div>
                    <div className='SCheckoutTM_payment'>
                        <div className='checkout_price_card'>
                            <div className='ChechoutSubPrice_head_Sec1'>
                                <span>Product</span>
                                <span>Total</span>
                            </div>
                            <div className='ChechoutSubPrice_head_Sec2'>
                                <span>Ladies New Collection</span>
                                <span>Rs. 750</span>
                            </div>
                            <div className='ChechoutSubPrice_head_S1'>
                                <span>Subtotal</span>
                                <div className='SB_totalP'>
                                    <span>Rs. </span>
                                    <span>750</span>
                                </div>
                            </div>
                            <div className='CheckoutSubPrice_ship_S2'>
                                <p>Shipping</p>
                                <div className='CTP_shipopingMethod'>
                                    <label><input type='radio' /> Cash on Delivery</label>
                                    <span>Rs. 200</span>
                                </div>
                            </div>
                            <div className='CheckoutSubPrice_shipTotal_S3'>
                                <span>Total</span>
                                <div className='CTP_shipT_Price'>
                                    <span>Rs. </span>
                                    <span>950</span>
                                </div>
                            </div>
                        </div>
                        <div className='CTP_ProceedToCheckout'>
                            <button>Proceed to checkout</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </>        
    );
}
export default CheckoutPage;