import './wishlistM.css';
import WishListCard from "../globle_component/wishL_Card";
import NavBarAafterLogin from '../NavB_AL';
import SideBar from '../SidebarN';


const WishList = () =>{
    return ( <>
        <NavBarAafterLogin/>
        <div className="dashboard_u">
            <SideBar/>
            <div className="S_wishlist_Main">
                <div className='CommanPageHeaderTitle'>
                    <h3>Wishlist</h3>
                </div>
                <WishListCard />
                <WishListCard />
                <WishListCard />
                <div className='S_WishL_footer'><button className='All_WLP_AtoC'>Add to cart</button></div>
            </div>
        </div>    
    </>
    );
}
export default WishList;