import wishlist_img from '../../imgs/wishlist.png';
import React, { useState } from 'react';
import './ProductDetailPg.css';
import { Link } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import NavBarAafterLogin from '../NavB_AL';
import SideBar from '../SidebarN';

const ProductDetailPage = (props) => {
    const location = useLocation()
    const{id} = location.state
    const [demo_data, ] = useState([
        {
           p_id: 1,
           title: "Stylish Charcoal Sleeves Zipper Fleece Winter Jacket for Men",
           img_url: "./assets/imgs/p2-1.jpg",
           options: [
              "./assets/imgs/p2-1.jpg",
              "./assets/imgs/p2-2.jpg"
           ],
           OrignalPrice: 1299,
           WholesalePrice: 975
        },
        {
            p_id: 2,
           title: "KD99 Ultra Smart Watch Series 8 NFC 1.99 Inches Smartwatch Men",
           img_url: "./assets/imgs/p3-3.jpg",
           options: [
              "./assets/imgs/p3-3.jpg",
              "./assets/imgs/p3-1.jpg",
              "./assets/imgs/p3-2.jpg"
           ],
           OrignalPrice: 4513,
           WholesalePrice: 3199
        },
        {
            p_id: 3,
            title: "Pack of 2 Half sleeves basic T shirt for men",
           img_url: "./assets/imgs/p4-3.jpg",
           options: [
              "./assets/imgs/p4-3.jpg",
              "./assets/imgs/p4-2.jpg",
              "./assets/imgs/p4-1.jpg",
              "./assets/imgs/p4-4.jpg"
           ],
           OrignalPrice: 1500,
           WholesalePrice: 999
        },
        {
            p_id: 4,
            title: "Stitched Stylish Embroidered Pearl Shirt With Trouser and Dupatta (Three Piece Suit) For Women/ Embroidered 2-piece Suit for Women/Girls/Ladies",
            img_url: "./assets/imgs/p5-1.jpg",
            options: [
               "./assets/imgs/p5-1.jpg",
               "./assets/imgs/p5-2.jpg",
               "./assets/imgs/p5-3.jpg"
            ],
            OrignalPrice: 3500,
            WholesalePrice: 1850
         }    
  ]);

    return (
        <>
        <NavBarAafterLogin />
        
        <div className="dashboard_u">    
            <SideBar/>
            {demo_data.map((item) => {

                if(item.p_id === id){
                    return <div className="ProductDP_Main">
                <div className="ProductDP_S1">
                    <div className="PDP_S1_left">
                        <img src={item.img_url} alt="Product Detail Page" className='PDP_s1L_MainImage'/>
                        <div className='PDP_s1L_imagesCollection'>
                            { item.options.map((newi,index) => {
                                return <><img src={newi} alt="p_img" className='Img_PDP_active' /></>;
                            })}
                            {/* <img src={PImg} alt="p_img" className='Img_PDP_active' />
                            <img src={PImg} alt="p_img" />
                            <img src={PImg} alt="p_img" />
                            <img src={PImg} alt="p_img" /> */}
                        </div>
                    </div>
                    <div className="PDP_S1_right">
                        <h3 className="ProductTile_PDP">{item.title}</h3>
                        <span className="PDP_produt_OP">{item.OrignalPrice}</span>
                        <div className="PDP_Product_WP">
                            <h4>WholeSale Price:</h4>
                            <h4>{item.WholesalePrice}</h4>
                        </div>
                        <div className="PDP_status">
                            <span>Status: </span>
                            <span>In stock</span>
                        </div>
                        <div className="PDP_Quantity_ADDWL">
                            <input type="number" id="quantity" name="quantity" min="1" max="5"/>
                            <label><img src={wishlist_img} alt='Wishlist_img' />  Add to Wishlist</label>
                        </div>
                        <div className='PDP_download_btns'>
                            <button>Download Iamges</button>
                            <button>Download Video</button>
                        </div>
                        <div className='PDP_AddTC_Odr'>
                            <Link to="/cart" ><button>Add to Cart</button></Link>
                            <button>Order Now</button>
                        </div>
                    </div>
                </div>
                <div className='PDP_descriptionBox'>
                    <ul className='PDP_desBox_nav'>
                        <li className='PDPD_DBox_Nav_active'>Description</li>
                        <li>Vendor</li>
                    </ul>
                    <div className='PDP_DB_des'>
                        <p>1.Convenient and practical: no longer stop grabbing the soap bottle. Any other sponge or scrubber can also be used.</p>
                    </div>
                </div>
            </div>;
            }
        return null;
        })}
       </div>
        </> 
    );
}
export default ProductDetailPage;