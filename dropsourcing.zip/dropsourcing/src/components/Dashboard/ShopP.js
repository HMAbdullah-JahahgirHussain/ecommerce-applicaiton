import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import ShopCard from "../globle_component/product_card";
// import ProductDetailPage from './ProductDetailPage';

const ShopPage = () => {
    const [demo_data, ] = useState([
        {
           p_id: 1,
           title: "Stylish Charcoal Sleeves Zipper Fleece Winter Jacket for Men",
           img_url: "./assets/imgs/p2-1.jpg",
           options: [
              "Scripting Language",
              "Markup Language",
              "Programming Language",
              "Network Protocol"
           ],
           OrignalPrice: 1299,
           WholesalePrice: 975
        },
        {
            p_id: 2,
           title: "KD99 Ultra Smart Watch Series 8 NFC 1.99 Inches Smartwatch Men",
           img_url: "./assets/imgs/p3-3.jpg",
           options: [
              "User defined tags",
              "Pre-specified tags",
              "Fixed tags defined by the language",
              "Tags only for linking"
           ],
           OrignalPrice: 4513,
           WholesalePrice: 3199
        },
        {
            p_id: 3,
            title: "Pack of 2 Half sleeves basic T shirt for men",
           img_url: "./assets/imgs/p4-3.jpg",
           options: [
              "1990",
              "1980",
              "2000",
              "1995"
           ],
           OrignalPrice: 1500,
           WholesalePrice: 999
        },
        {
            p_id: 4,
            title: "Stitched Stylish Embroidered Pearl Shirt With Trouser and Dupatta (Three Piece Suit) For Women/ Embroidered 2-piece Suit for Women/Girls/Ladies",
            img_url: "./assets/imgs/p5-1.jpg",
            options: [
               "1990",
               "1980",
               "2000",
               "1995"
            ],
            OrignalPrice: 3500,
            WholesalePrice: 1850
         }    
  ]);

//   var abc;

    return (
        <div className="dashB_content">
            {
            
                demo_data.map((items)=> {
                    return <Link to='/ProductDetail' state={{ id: items.p_id }} className='S_Product_cart' ><ShopCard PTile={items.title} PImg={items.img_url} POP={items.OrignalPrice} PWP={items.WholesalePrice}  /> </Link>;  
                })
            }
            {/* <ShopCard />
            <ShopCard />
            <ShopCard /> */}
        </div>
    );
}
export default ShopPage;