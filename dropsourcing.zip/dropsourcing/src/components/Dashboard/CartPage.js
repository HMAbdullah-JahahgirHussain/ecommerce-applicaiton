import CartPageCard from '../globle_component/Cart_Page_card';
import './CartPageM.css';
import { Link } from 'react-router-dom';
import React, { useState } from 'react';
import NavBarAafterLogin from '../NavB_AL';
import SideBar from '../SidebarN';


const CartPage = () =>{

    const [demo_data, ] = useState([
        {
           p_id: 1,
           title: "Stylish Charcoal Sleeves Zipper Fleece Winter Jacket for Men",
           img_url: "./assets/imgs/p2-1.jpg",
           options: [
              "./assets/imgs/p2-1.jpg",
              "./assets/imgs/p2-2.jpg"
           ],
           OrignalPrice: 1299,
           WholesalePrice: 975
        },
        {
            p_id: 2,
           title: "KD99 Ultra Smart Watch Series 8 NFC 1.99 Inches Smartwatch Men",
           img_url: "./assets/imgs/p3-3.jpg",
           options: [
              "./assets/imgs/p3-3.jpg",
              "./assets/imgs/p3-1.jpg",
              "./assets/imgs/p3-2.jpg"
           ],
           OrignalPrice: 4513,
           WholesalePrice: 3199
        },
        {
            p_id: 3,
            title: "Pack of 2 Half sleeves basic T shirt for men",
           img_url: "./assets/imgs/p4-3.jpg",
           options: [
              "./assets/imgs/p4-3.jpg",
              "./assets/imgs/p4-2.jpg",
              "./assets/imgs/p4-1.jpg",
              "./assets/imgs/p4-4.jpg"
           ],
           OrignalPrice: 1500,
           WholesalePrice: 999
        } 
  ]);



    return (<>
        <NavBarAafterLogin />
        
        <div className="dashboard_u">    
            <SideBar/>
            <div className="S_CartPage_Main">
                <div className='CommanPageHeaderTitle'>
                    <h3>Cart</h3>
                </div>
                <div className='List_info_bar'>
                    <ul>
                        <li className='LB_Product'>Product</li>
                        <li className='LB_Price'>Price</li>
                        <li className='LB_Quantity'>Quantity</li>
                        <li className='LB_total'>Total</li>
                    </ul>
                </div>
                { demo_data.map((nitems) => {
                    return <CartPageCard proImg={nitems.img_url} proTitle={nitems.title} proWP={nitems.WholesalePrice} />;
                })

                }
                {/* <CartPageCard />
                <CartPageCard /> */}
                <div className='S_CartP_2ndS'><button className='All_WLP_AtoC'>Back to Shop</button></div>
                <div className='S_Cart_total_Main'>
                    <div className='SCTM_box1'>
                        <div className='cart_total_price'>
                            <div className='CartTotalPrice_head_S1'>
                                <span>Subtotal</span>
                                <div className='SB_totalP'>
                                    <span>Rs. </span>
                                    <span>750</span>
                                </div>
                            </div>
                            <div className='CartTotalPrice_ship_S2'>
                                <p>Shipping</p>
                                <div className='CTP_shipopingMethod'>
                                    <label><input type='radio' /> Cash on Delivery</label>
                                    <span>Rs. 200</span>
                                </div>
                            </div>
                            <div className='CartTotalPrice_shipTotal_S3'>
                                <span>Total</span>
                                <div className='CTP_shipT_Price'>
                                    <span>Rs. </span>
                                    <span>950</span>
                                </div>
                            </div>
                        </div>
                        <div className='CTP_ProceedToCheckout'>
                            <Link to="/checkout"><button>Proceed to checkout</button></Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
        </>
    );
}
export default CartPage;