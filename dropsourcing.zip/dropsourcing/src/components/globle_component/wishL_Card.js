import PWLImg from '../../imgs/p5-1.jpg';
import PWLClose from '../../imgs/x.png';

const WishListCard = () =>{
    return (
        <div className="WishL_Card_main">
            <div>
                <img src={PWLClose} alt="WishL_Card_img" className='WL_remove_item'/>
                <img src={PWLImg} alt="WishL_Card_img" className='WL_P_IMG' />
                <span className='WL_P_title'>Ladies new collection</span>
            </div>
            <div><button className='Seprt_cart_btn'>Add to cart</button></div>
        </div>
    );
}
export default WishListCard;