// import PImg from '../../imgs/p5-1.jpg';
// import React, { useState } from 'react';

const ShopCard = (props) => {
    var percentege = 100 - Math.round((props.PWP/props.POP)*100);
    // className='S_Product_cart'
    return (
        <div>
            <img src={props.PImg} alt="p_img" className='S_Product_IMG' />
            <h3 className='S_product_name'>{props.PTile}</h3>
            <div className='S_prod_price_content'>
                <p className='S_product_price'>Rs.{props.PWP}</p>
                <div className='S_discount_div'>
                    <span  className='S_product_discount_price'>Rs.{props.POP}</span>
                    
                    <span className='S_product_discount_percentage'>-{percentege}%</span>
                </div>
            </div> 
        </div>
    );
}
export default ShopCard;