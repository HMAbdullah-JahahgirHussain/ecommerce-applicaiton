import W1 from '../../imgs/WS_1.jpg';

const WholesalerInfoDashboard = () =>{
    return (
        <div className="DUW_info_card">
            <img src={W1} alt="W_info" />
            <p>SFH</p>
        </div>
    );
}
export default WholesalerInfoDashboard;