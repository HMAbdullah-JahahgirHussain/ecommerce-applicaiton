// import PWLImg from '../../imgs/p5-1.jpg';
import PWLClose from '../../imgs/x.png';


const CartPageCard = (props) =>{
    return (
        <div className="CartPageCard_main">
            <div className='CPC_Product'>
                <img src={PWLClose} alt="CPC_Card_img" className='CPC_remove_item'/>
                <img src={props.proImg} alt="CPC_Card_img" className='CPC_P_IMG' />
                <span className='CPC_P_title'>{props.proTitle}</span>
            </div>
            <div className='CPC_Price'>
                <span>Rs. </span><span>{props.proWP}</span>
            </div>
            <div className='CPC_Quantity'>
                {/* - + */}
                <input type="number" id="quantity" name="quantity" min="1" max="5"/>
                <span>1</span>
            </div>
            <div className='CPC_TotalP'>
                <span>Rs. </span><span>750</span>
            </div>
        </div>
    );
}
export default CartPageCard;