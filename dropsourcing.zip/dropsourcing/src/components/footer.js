import { Component } from "react";

class FooterSite extends Component{
    render(){
        return(
            <>
                <div className="Site_footer">
                    <p>© Dropsoucing, 2022 All Rights Reserved</p>
                </div>
            </>
        );
    }
}

export default FooterSite;