import './logP.css';
import { Link  } from 'react-router-dom';
import MainHeader from '../MainHeader';


const LoginP = () => {
        return ( <>
            <MainHeader />
            <div className="LoginMain">
                <h1 className='Page_title'>Login</h1>
            </div>
            <div className="login_form">
                <div className="login_input">
                    <label className="lg_label">Username or email address <span className="strk_must">*</span></label>
                    <input type="text" placeholder="Email address or phone number"/>
                    <label className="lg_label">Password <span className="strk_must">*</span></label>
                    <input type="password" placeholder="Password"/>
                </div>
                <div className="login_submit"><Link to='/Udashboard'><input type="submit" value="Log in"/></Link></div>
                <div className="lnks_txt">
                    <Link to="/lostPass"><p>Don't have Account?</p></Link>
                    {/* <p>Lost your password?</p> */}
                    {/* <p>Don't have Account?</p> */}
                    <Link to="/register"><p>Don't have Account?</p></Link>
                </div>
            </div>

        </>
    );
}

export default LoginP;