import MainHeader from '../MainHeader';
import './logP.css';
// import { Link  } from 'react-router-dom';


const LostPass = () => {
        return ( <>
            <MainHeader/>
            <div className="RegMain">
                <h1 className='Page_title'>Login</h1>
                <p><b><u>Note:</u></b> Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.</p>
            </div>
            <div className="login_form">
                <div className="login_input">
                    <label className="lg_label">Username or email address <span className="strk_must">*</span></label>
                    <input type="text" placeholder="Email address or phone number"/>
                </div>
                <div className="login_submit"><input type="submit" value="Rest password"/></div>
            </div>

        </>
    );
}

export default LostPass;