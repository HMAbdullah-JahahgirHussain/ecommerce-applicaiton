import './Dashboard/Udash.css';
import WholesalerInfoDashboard from "./globle_component/dash_wholesaler_info";
// import ShopCard from "./globle_component/product_card";
// import NavBarAafterLogin from './NavB_AL';

const SideBar = () => {
    return (<>
        {/* <NavBarAafterLogin /> */}
        {/* <div className="dashboard_u"> */}
            <nav className="SideBar_dash">
                <div className="Dash_user_welcome">
                    <span>Welcome! </span>
                    <span>Sabri Fashion House</span>
                </div>
                <div className="Dash_user_wholesalers">
                    <h2>WholeSaler</h2>
                    <div className="DUW_info">
                        <WholesalerInfoDashboard />
                        <WholesalerInfoDashboard />
                        <WholesalerInfoDashboard />
                    </div>
                </div>
                <ul className="Dash_user_Nlinks">
                    <li className="DuNL_active">Order</li>
                    <li>Finance</li>
                    <li>Business Profiles</li>
                </ul>
                <div className="Dash_user_Company_info">
                    <h3>Hi! I am Hafiz Muhammad Abdullah,</h3>
                    <p>your dedicated account manager</p>
                    <p>Feel free to contact me at <b>0316-4281217</b> for any query.</p>
                </div>
            </nav>
            {/* <div className="dashB_content">
                <ShopCard />
                <ShopCard />
                <ShopCard />
            </div> */}
        {/* </div> */}
    </>    
    );
}
export default SideBar;