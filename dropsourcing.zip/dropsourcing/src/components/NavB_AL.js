import '../index.css';
import { Link  } from 'react-router-dom';
import cart_img from '../imgs/shopping-cart.png';
import wishlist_img from '../imgs/wishlist.png';
import Acnt_img from '../imgs/user.png';


const NavBarAafterLogin = () => {
    return(
        <header id="after-login-header">
            <div className="logo_AH">
                <a href="https://dropsources.zeeshanikram.com/dashboard/">
                <img src="./assets/imgs/site_logo.png" alt="Biggest Dropshipping Service in Pakistan" id="logo" data-height-percentage="100" />
                </a>
            </div>
            <div className="Search_AH">
                <form role="search" method="get" className="search-form" action="https://dropsources.zeeshanikram.com/">
                    <label>
                        <span className="screen-reader-text">Search for:</span>
                        <input type="search" className="search-field" placeholder="Search …" value="" name="s" />
                    </label>
                    <input type="submit" className="search-submit" value="Search" />
                </form>
                <Link to="/Udashboard"><img src="./assets/imgs/shop-now.png" alt="shop_PG" /></Link>
            </div>
            <div className="Wish_btns_AH">
                <Link to="/cart">
                    <span><img src={cart_img} alt='Cart_img' /></span>
                </Link>
                <Link to="/Wishlist">
                    <span><img src={wishlist_img} alt='Wishlist_img' /></span>
                </Link>
                <Link to="/Udashboard">
                    <span><img src={Acnt_img} alt='Account_img' /></span>
                </Link>
            </div>
        </header>
    );
}
export default NavBarAafterLogin;