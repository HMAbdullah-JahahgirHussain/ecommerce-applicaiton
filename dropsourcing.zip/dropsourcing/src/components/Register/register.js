import { Link  } from 'react-router-dom';
import './regs.css';
import '../../globle.css';
import MainHeader from '../MainHeader';


const RegisterP = () => {
        return ( <>
            <MainHeader />
            <div className="RegMain">
                <h1 className='Page_title'>Register</h1>
                <p><b><u>Note:</u></b> Kindly fill the form completely. Otherwise, your application will be rejected.</p>
            </div>
            <div className="regis_form">
                <div className="regis_input">
                    <label className="lg_label">Your Name <span className="strk_must">*</span></label>
                    <input type="text" placeholder="Email address or phone number"/>
                    <label className="lg_label">E-mail <span className="strk_must">*</span></label>
                    <input type="password" placeholder="Password"/>
                    <label className="lg_label">Password <span className="strk_must">*</span></label>
                    <input type="text" placeholder="Email address or phone number"/>
                    <label className="lg_label">Confirm Password <span className="strk_must">*</span></label>
                    <input type="password" placeholder="Password"/>
                    <label className="lg_label">Whatsapp Number <span className="strk_must">*</span></label>
                    <input type="text" placeholder="Email address or phone number"/>
                    <label className="lg_label">CNIC (without <b>-</b> ) <span className="strk_must">*</span></label>
                    <input type="password" placeholder="Password"/>
                </div>
                <div className='radio_btns'>
                    <input type="radio" value="Male" name="gender" /> I am Reseller
                    <input type="radio" value="Female" name="gender" /> I am Wholeseller
                </div>
                <div className="Register_submit">
                    <input type="submit" value="Register"/>
                    <Link to="/login"><button className='reg_LoginBtn'>Login</button></Link>
                </div>
            </div>

        </>);
}

export default RegisterP;